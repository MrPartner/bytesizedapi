package com.ByteSizedAPI.plugins

import io.ktor.server.application.*

fun Application.configureSecurity() {
    
}
